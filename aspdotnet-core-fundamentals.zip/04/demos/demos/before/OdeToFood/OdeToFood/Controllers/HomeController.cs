﻿namespace OdeToFood.Controllers
{
    public class HomeController
    {
        public string Index()
        {
            return "Hello from the HomeController!";
        }
    }
}
